# SentientBMS — AI-Powered Autonomous Smart Building Optimization

SentientBMS is an AI-powered autonomous Building Management System (BMS) that integrates a physical building thermal model, an MCP-like simulation sandbox, a deterministic safety gate, and a cost optimization layer.

## Architecture Highlights
* **Symbiotic Digital Twin Sandbox:** When making setpoint decisions, the AI agent proposes multiple candidate strategies, runs fast-forward parallel simulations in a digital twin emulator to evaluate energy, carbon, and comfort penalties, and selects the optimal approach.
* **Deterministic Safety Gate:** Rejects unsafe setpoint changes, boundary violations, or fast ramp rates that could damage mechanical equipment or compromise safety, falling back to a rule-based scheduler.
* **Dynamic Optimization Objectives:** Allows real-time weight adjustments for energy cost, carbon footprint, and comfort compliance.

## Project Structure
```
smart-building-ai/
├── simulation/
│   └── building_model.py     # 3-Zone Thermodynamic Model
├── baseline/
│   └── rule_based_controller.py # Standard Scheduled Control (RBC)
├── safety/
│   └── validator.py          # Safety bounds & deadband checks
├── optimization/
│   └── objective.py          # Weight-based Cost function J
├── mcp_server/
│   └── server.py             # MCP Tool Interfaces
├── ai_agent/
│   └── agent.py              # Strategy candidates selection
├── dashboard/
│   └── app.py                # Streamlit Dashboard UI
├── runner.py                 # Simulation orchestrator
└── tests/
    └── test_safety.py        # Safety validation checks
```

## Setup & Running Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Execute Simulation Loop
Run the simulator to run 24 hours of baseline vs AI comparative scenarios:
```bash
python runner.py
```

### 3. Launch interactive Dashboard
Run the Streamlit app:
```bash
streamlit run dashboard/app.py
```
This launches a browser session presenting comparative analytics, setpoints, energy savings, carbon emissions, comfort, and the AI log showing explainable decisions.
